from django.apps import AppConfig


class MusicStreamerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Music_streamer'
